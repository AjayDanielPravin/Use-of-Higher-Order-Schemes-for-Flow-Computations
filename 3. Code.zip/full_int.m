% %4th order CDS 
% a = 4/3;
% b =-1/3;
% c =0;
% alp= 0;
% bet =0;

%6th order tridiagonal scheme
a = 14/9;
b =1/9;
c =0;
alp= 1/3;
bet =0;

% % 8th order pentadiagonal scheme
% a = 40/27;
% b =25/54;
% c =0;
% alp= 4/9;
% bet =1/36;

%10th order pentadiagonal scheme
a = 17/12;
b =101/150;
c =1/100;
alp= 1/2;
bet =1/20;


%Wave number comparisons
w = linspace(0,3,100);
% w_m = (a*sin(w) + (b/2)*sin(2*w) + (c/3)*sin(3*w))/(1+2*alp*cos(w) + 2*bet*cos(2*w));
w_m = (a*cos(w/2)+(b)*cos(3*w/2)+(c)*cos(5*w/2))./(1+ 2*alp*cos(w)+ 2*bet*cos(2*w));

plot(w, 1);
hold on;
