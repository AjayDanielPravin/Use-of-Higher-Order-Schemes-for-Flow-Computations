

% %8th order pentadiagonal scheme
% a = 40/27;
% b =25/54;
% c =0;
% alp= 4/9;
% bet =1/36;

%10th order pentadiagonal scheme
a = 17/12;
b =101/150;
c =1/100;
alp= 1/2;
bet =1/20;

w = linspace(0,3,100);
w_m = (a*cos(w/2)+(b)*cos(3*w/2)+(c)*cos(5*w/2))./(1+ 2*alp*cos(w)+ 2*bet*cos(2*w));
plot(w, w_m);
hold on;
