

% %8th order pentadiagonal scheme
% a = 40/27;
% b =25/54;
% c =0;
% alp= 4/9;
% bet =1/36;

%10th order pentadiagonal scheme
a = 17/12;
b =101/150;
c =1/100;
alp= 1/2;
bet =1/20;

%Spectral 4th order
a = 1.30251;
b =0.99355;
c = 0.03750;
alp= 0.577143;
bet =0.08964;

%Wave number comparisons
w = linspace(0,3,100);
% w_m = (a*sin(w) + (b/2)*sin(2*w) + (c/3)*sin(3*w))/(1+2*alp*cos(w) + 2*bet*cos(2*w));
w_m = (a*sin(w)+(b/2)*sin(2*w)+(c/3)*sin(3*w))./(1+ 2*alp*cos(w)+ 2*bet*cos(2*w));

plot(w, w_m);
hold on;