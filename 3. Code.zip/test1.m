m=0.7;
w = linspace(0,3,100);
w_m = cos(w)*2*m;
plot(w_m,w);