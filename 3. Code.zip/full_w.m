% %2nd order CDS
% a = 1/2;
% b =0;
% c =0;
% alp= 0;
% bet =0;

% %4th order CDS 
% a = 4/3;
% b =-1/3;
% c =0;
% alp= 0;
% bet =0;

% %6th order tridiagonal scheme
% a = 14/9;
% b =1/9;
% c =0;
% alp= 1/3;
% bet =0;

% %8th order tridiagonal scheme
% a = 19/12;
% b =1/6;
% c =0;
% alp= 3/8;
% bet =0;


% % 8th order pentadiagonal scheme
% a = 40/27;
% b =25/54;
% c =0;
% alp= 4/9;
% bet =1/36;

% %10th order pentadiagonal scheme
% a = 17/12;
% b =101/150;
% c =1/100;
% alp= 1/2;
% bet =1/20;

%Spectral 4th order
a = 1.30251;
b =0.99355;
c = 0.03750;
alp= 0.577143;
bet =0.08964;

%Comparisons between
%Wave number comparisons
w = linspace(0,3,100);
% w_m = (a*sin(w) + (b/2)*sin(2*w) + (c/3)*sin(3*w))/(1+2*alp*cos(w) + 2*bet*cos(2*w));
w_m = (a*sin(w)+(b/2)*sin(2*w)+(c/3)*sin(3*w))./(1+ 2*alp*cos(w)+ 2*bet*cos(2*w));

plot(w, w_m);
hold on;

