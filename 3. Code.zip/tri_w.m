%Modified wavenumber - Fourier error

%Transfer function


%Tridiagonal Schemes (bet = 0)
%4th order tridiagonal schemes



% %6th order tridiagonal scheme
% a = 14/9;
% b =1/9;
% c =0;
% alp= 1/3;
% bet =0;

%8th order tridiagonal scheme
a = 19/12;
b =1/6;
c =0;
alp= 3/8;
bet =0;

%Wave number comparisons
w = linspace(0,3,100);
% w_m = (a*sin(w) + (b/2)*sin(2*w) + (c/3)*sin(3*w))/(1+2*alp*cos(w) + 2*bet*cos(2*w));
w_m = (a*sin(w)+(b/2)*sin(2*w)+(c/3)*sin(3*w))./(1+ 2*alp*cos(w)+ 2*bet*cos(2*w));

plot(w, w_m);
hold on;


