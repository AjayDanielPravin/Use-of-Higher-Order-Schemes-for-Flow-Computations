%Finite Difference comparisons

% %2nd order
% a = 1/2;
% b =0;
% c =0;
% alp= 0;
% bet =0;

%4th order CDS 
a = 4/3;
b =-1/3;
c =0;
alp= 0;
bet =0;

%Wave number comparisons
w = linspace(0,3,100);
% w_m = (a*sin(w) + (b/2)*sin(2*w) + (c/3)*sin(3*w))/(1+2*alp*cos(w) + 2*bet*cos(2*w));
w_m = (a*sin(w)+(b/2)*sin(2*w)+(c/3)*sin(3*w))./(1+ 2*alp*cos(w)+ 2*bet*cos(2*w));

plot(w, w_m);
hold on;