%Midpoint interpolation

%Transfer function

a =
b =
c =
alp= 
bet =


T = 